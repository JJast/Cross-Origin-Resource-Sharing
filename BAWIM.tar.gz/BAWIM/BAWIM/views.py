from django.shortcuts import render

def index(request):
    context ={
        "list":[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
}
    return render(request, "index.html", context)
